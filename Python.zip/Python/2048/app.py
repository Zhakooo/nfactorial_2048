from flask import Flask, render_template, request, jsonify
from game import Game

app = Flask(__name__)

game = Game()

@app.route('/')
def index():
    return render_template('index.html', board=game.get_board())

@app.route('/move_left', methods=['POST'])
def move_left():
    game.move_left()
    game.add_random_tile()
    return jsonify({'board': game.get_board(), 'game_over': game.is_game_over(), 'win': game.is_game_won()})

@app.route('/move_right', methods=['POST'])
def move_right():
    game.move_right()
    game.add_random_tile()
    return jsonify({'board': game.get_board(), 'game_over': game.is_game_over(), 'win': game.is_game_won()})

@app.route('/move_up', methods=['POST'])
def move_up():
    game.move_up()
    game.add_random_tile()
    return jsonify({'board': game.get_board(), 'game_over': game.is_game_over(), 'win': game.is_game_won()})

@app.route('/move_down', methods=['POST'])
def move_down():
    game.move_down()
    game.add_random_tile()
    return jsonify({'board': game.get_board(), 'game_over': game.is_game_over(), 'win': game.is_game_won()})

if __name__ == '__main__':
    app.run()
