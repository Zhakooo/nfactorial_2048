import random

class Game:
    def __init__(self):
        self.board = [[0] * 4 for _ in range(4)]
        self.score = 0
        self.add_random_tile()
        self.add_random_tile()

    def add_random_tile(self):
        empty_cells = [(i, j) for i in range(4) for j in range(4) if self.board[i][j] == 0]
        if empty_cells:
            row, col = random.choice(empty_cells)
            self.board[row][col] = random.choice([2, 4])

    def move_left(self):
        for row in self.board:
            row[:] = self.merge(row)
        self.add_random_tile()

    def move_right(self):
        for row in self.board:
            row[:] = self.merge(row[::-1])[::-1]
        self.add_random_tile()

    def move_up(self):
        for col in range(4):
            column = [self.board[row][col] for row in range(4)]
            merged_column = self.merge(column)
            for row in range(4):
                self.board[row][col] = merged_column[row]
        self.add_random_tile()

    def move_down(self):
        for col in range(4):
            column = [self.board[row][col] for row in range(4)]
            merged_column = self.merge(column[::-1])[::-1]
            for row in range(4):
                self.board[row][col] = merged_column[row]
        self.add_random_tile()

    def merge(self, line):
        merged_line = [0] * 4
        i = 0
        j = 0
        while i < 4:
            if i == 3:
                merged_line[j] = line[i]
                break
            if line[i] == 0:
                i += 1
                continue
            if line[i] == line[i + 1]:
                merged_line[j] = line[i] * 2
                self.score += merged_line[j]
                i += 2
            else:
                merged_line[j] = line[i]
                i += 1
            j += 1
        return merged_line

    def is_game_over(self):
        for i in range(4):
            for j in range(4):
                if self.board[i][j] == 0:
                    return False
                if j < 3 and self.board[i][j] == self.board[i][j + 1]:
                    return False
                if i < 3 and self.board[i][j] == self.board[i + 1][j]:
                    return False
        return True

    def is_game_won(self):
        for row in self.board:
            if 2048 in row:
                return True
        return False

    def get_board(self):
        return [[cell if cell != 0 else '' for cell in row] for row in self.board]

    def print_board(self):
        for row in self.board:
            print(row)
