window.addEventListener('DOMContentLoaded', (event) => {
    const easyButton = document.getElementById('easy-button');
    const mediumButton = document.getElementById('medium-button');
    const hardButton = document.getElementById('hard-button');
  
    function handleEasyButtonClick() {
      
    }
  
    function handleMediumButtonClick() {
      
    }
  
    function handleHardButtonClick() {
      
    }
  
    if (easyButton) {
      easyButton.addEventListener('click', handleEasyButtonClick);
    }
  
    if (mediumButton) {
      mediumButton.addEventListener('click', handleMediumButtonClick);
    }
  
    if (hardButton) {
      hardButton.addEventListener('click', handleHardButtonClick);
    }
  });
  

  // для индекс хтмл
//   <!DOCTYPE html>
// <html>
// <head>
//   <meta charset="UTF-8">
//   <title>2048 Game</title>
//   <link rel="stylesheet" type="text/css" href="{{ url_for('static', filename='style.css') }}">
// </head>
// <body>
//   <div class="container">
//     <h1 class="title">2048 Game</h1>
//     <div class="level-buttons">
//       <button id="easy-button">Легкий</button>
//       <button id="medium-button">Средний</button>
//       <button id="hard-button">Сложный</button>
//     </div>
//     <div id="board"></div>
//   </div>

//   <script src="{{ url_for('static', filename='js/game.js') }}"></script>
// </body>
// </html>
