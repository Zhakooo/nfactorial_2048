
document.addEventListener('keydown', function(event) {
  if (event.key === 'ArrowLeft') {
    moveLeft();
  } else if (event.key === 'ArrowRight') {
    moveRight();
  } else if (event.key === 'ArrowUp') {
    moveUp();
  } else if (event.key === 'ArrowDown') {
    moveDown();
  }
});

function moveLeft() {
  makeMove('/move_left');
}

function moveRight() {
  makeMove('/move_right');
}

function moveUp() {
  makeMove('/move_up');
}

function moveDown() {
  makeMove('/move_down');
}

function makeMove(url) {
  fetch(url, {
    method: 'POST'
  })
  .then(function(response) {
    return response.json();
  })
  .then(function(data) {
    updateBoard(data.board);
    if (data.game_over) {
      alert('Game over!');
    } else if (data.win) {
      alert('You win!');
    }
  })
  .catch(function(error) {
    console.log('Error:', error);
  });
}

function updateBoard(board) {

}